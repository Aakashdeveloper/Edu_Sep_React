import React from 'react';

const Footer = () => {

    return(
        <footer>
            <hr/>
            <center>
                <h3>&copy; Developer Funnel</h3>
            </center>
        </footer>
    )
}

export default Footer;
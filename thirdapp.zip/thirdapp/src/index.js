import React from 'react';
import ReactDOM from 'react-dom';
import Search from './component/Search';

ReactDOM.render(<Search/>,document.getElementById('root'))